
 

const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
document.body.appendChild(canvas);
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let angle = 20;
//chatgpt
    var topRect = document.createElement('div');
    var bottomRect = document.createElement('div');
    
    topRect.style.position = 'fixed';
    topRect.style.left = '0';
    topRect.style.top = '0';
    topRect.style.width = '100%';
    topRect.style.height = '10%';
    topRect.style.backgroundColor = 'rgba(0, 0, 0, 3.5)';
    
    bottomRect.style.position = 'fixed';
    bottomRect.style.left = '0';
    bottomRect.style.bottom = '0';
    bottomRect.style.width = '100%';
    bottomRect.style.height = '10%';
    bottomRect.style.backgroundColor = 'rgba(0, 0, 0, 3.5)';
    
    document.body.appendChild(topRect);
    document.body.appendChild(bottomRect);
    
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  ctx.save();
  ctx.translate(450, 500);
  ctx.rotate(angle);

  ctx.beginPath();
  ctx.arc(0, 0, 200, 0, 2 * Math.PI);
  ctx.fillStyle = "black";
  ctx.fill();
  ctx.stroke();
  
  ctx.beginPath();
  ctx.arc(0, 200, 500, 0, 2 * Math.PI);
  ctx.fillStyle = "black";
  ctx.fill();
  ctx.stroke();

   ctx.beginPath();
 ctx.strokeStyle = "#fbff00";
    ctx.fillStyle = "white";
ctx.arc(450, 100, 500, 0, Math.PI);
    ctx.stroke();
    ctx.fill();
  

  ctx.restore();

  angle += 0.05;
  requestAnimationFrame(animate);
}

animate();